// Filmes
const filmesContainer = document.getElementById('filmesContainer');
const esquerda = document.querySelector('.seta.esquerda');
const direita = document.querySelector('.seta.direita');

esquerda?.addEventListener('click', () => {
    filmesContainer.scrollBy({ left: -300, behavior: 'smooth' });
});

direita?.addEventListener('click', () => {
    filmesContainer.scrollBy({ left: 300, behavior: 'smooth' });
});

// Séries
const seriesContainer = document.getElementById('seriesContainer');
const esquerdaSeries = document.querySelector('.seta.esquerda-series');
const direitaSeries = document.querySelector('.seta.direita-series');

esquerdaSeries?.addEventListener('click', () => {
    seriesContainer.scrollBy({ left: -300, behavior: 'smooth' });
});

direitaSeries?.addEventListener('click', () => {
    seriesContainer.scrollBy({ left: 300, behavior: 'smooth' });
});